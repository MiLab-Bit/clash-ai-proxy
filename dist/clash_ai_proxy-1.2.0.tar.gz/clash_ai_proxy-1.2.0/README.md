# Clash AI Proxy

**Test which of your proxy nodes can actually reach ChatGPT, Claude, Gemini — then auto-generate an optimized layered Clash/Shadowrocket config.**

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](CONTRIBUTING.md)

```
$ clash-ai test --proxy http://127.0.0.1:7897 --services chatgpt,gemini,claude

============================================================
  Testing Services via http://127.0.0.1:7897
============================================================

Service                   Status   Latency    Verdict
-----------------------------------------------------------------
+ ChatGPT                 200      732ms      REACHABLE
+ Google Gemini           204      3184ms     REACHABLE
x Claude (Anthropic)      403      2791ms     BLOCKED (CF anti-bot)

Result: 2/3 services reachable
```

```
$ clash-ai latency --config ~/.config/clash/config.yaml

Node            Samples                        Avg      Jitter   Verdict
-----------------------------------------------------------------------
SG-02    [398, 402, 402, 399, 402]     401ms    4ms      stable
SG-01    [1908, 801, 1699, 1502, 1398] 1462ms   1110ms   UNSTABLE
HK-01    [895, 401, 404, 3399, 696]    1159ms   2998ms   UNSTABLE
Warp-CF  DEAD                           N/A      N/A      DEAD NODE
```

---

## The Problem

Your Clash/Shadowrocket proxy has 10+ nodes. `url-test` picks the "fastest" one — but:

- A node with **50ms latency to `gstatic.com`** might be **completely dead for OpenAI** (returns `000`)
- A node that works for ChatGPT might be **region-blocked for Gemini** (Google rejects the IP range)
- A node with great **average latency** might have **severe jitter** (spikes from 400ms to 1900ms)
- Some airports inject **fake nodes** ("Remaining Traffic: 995GB") that `url-test` may select

**You don't have a "fastest node" problem. You have a "which node works for which service" problem.**

## The Solution

Clash AI Proxy is a CLI tool that:

1. **Tests** each of your nodes against real AI services (ChatGPT, Claude, Gemini, Grok, Perplexity)
2. **Measures** latency stability — not just average, but jitter and dead-node detection
3. **Classifies** nodes: `excellent` / `good` / `unstable` / `dead` / `region-blocked`
4. **Generates** an optimized layered proxy group config with service-specific health checks

## Quick Start

```bash
# Install
pip install clash-ai-proxy

# 1. Test which services your current proxy can reach
clash-ai test --proxy http://127.0.0.1:7897

# 2. Test node latency and stability
clash-ai latency --config ~/.config/clash/config.yaml

# 3. Full pipeline: test everything → generate optimized config
clash-ai full --config ~/.config/clash/config.yaml --proxy http://127.0.0.1:7897
```

No `pip install`? Run directly from source:

```bash
git clone https://github.com/MiLab-Bit/clash-ai-proxy.git
cd clash-ai-proxy
pip install -r requirements.txt  # requests, PyYAML
python -m clash_ai_proxy.cli test --proxy http://127.0.0.1:7897
```

## The 11-Layer Architecture

Most Clash configs use 2-3 proxy groups. **Clash AI Proxy** organizes traffic into 11 groups by risk profile:

| # | Group | Type | Covers | Why |
|---|-------|------|--------|-----|
| 1 | **Google-AI** | fallback | Gemini, NotebookLM, AI Studio | Google blocks certain IP ranges — exclude them |
| 2 | **AI-Services** | fallback | ChatGPT, Claude, Grok, Perplexity | Some nodes are dead for OpenAI even if they work for everything else |
| 3 | Note-Tools | url-test | Notion, Obsidian, Craft | Low-stakes — any working node is fine |
| 4 | Dev-AI | url-test | Cursor, GitHub Copilot, Replit | Low-stakes |
| 5 | CF-Strict | select | Perplexity, Mistral, Poe, Sora | Cloudflare Bot Management — needs residential IP, manual selection |
| 6 | Social | fallback | Telegram, Discord, WhatsApp | High-frequency — needs stability |
| 7 | Dev-Svc | fallback | Docker, PyPI, npm, Vercel | High-frequency — needs stability |
| 8 | Web3 | fallback | Binance, Coinbase, DeFi, Wallets | Exchange geo-blocking varies |
| 9 | Finance | fallback | Bloomberg, Reuters, NYT | News/finance geo-blocking |
| 10 | Streaming | fallback | Netflix, Disney+, YouTube, Spotify | Needs consistent exit IP for session continuity |
| 11 | Shopping | fallback | Amazon, eBay, Zara, Sephora | E-commerce geo-blocking |

### Why `fallback` instead of `url-test` for AI?

| | `url-test` | `fallback` |
|---|---|---|
| Selects by | Lowest latency to test URL | First available node (ordered by priority) |
| Test URL | Usually `gstatic.com/generate_204` | **Service-specific** (e.g., `chatgpt.com/cdn-cgi/trace`) |
| Problem | A node fast for gstatic may be **dead for OpenAI** | Health check uses the **actual service** — dead nodes are skipped |
| Behavior | Jumps to "fastest" node constantly | Stays on current node until it fails |

## How It Works

```
Your Clash config (nodes)
        │
        ▼
  ┌─────────────┐
  │  CLI: test  │ ── Tests each service through your proxy
  └─────────────┘
        │
        ▼
  ┌─────────────┐
  │ CLI: latency│ ── TCP+TLS handshake test, 5 samples per node
  └─────────────┘      Measures avg, min, max, jitter
        │
        ▼
  ┌─────────────┐
  │  Classify   │ ── excellent / good / unstable / dead / region-blocked
  └─────────────┘
        │
        ▼
  ┌─────────────┐
  │  Generate   │ ── Outputs optimized config with dead/unstable nodes excluded
  └─────────────┘      Clash YAML or Shadowrocket .conf
```

## Comparison

| Feature | [Loyalsoldier](https://github.com/Loyalsoldier/clash-rules) (18k★) | [blackmatrix7](https://github.com/blackmatrix7/ios_rule_script) (20k★) | [ACL4SSR](https://github.com/ACL4SSR/ACL4SSR) (3.1k★) | **This Project** |
|---------|--------|--------|--------|--------|
| What it gives you | Domain rule lists | Per-service rule files | Rule fragments | **Proxy group architecture + node testing tool** |
| Answers the question | "Which domains to proxy?" | "Which domains to proxy?" | "Which domains to proxy?" | **"Which nodes to use for each service?"** |
| AI-specific routing | ❌ | Rule files only | ❌ | **✅ Per-service health checks** |
| Dead node detection | ❌ | ❌ | ❌ | **✅ CLI tests each node** |
| Latency stability test | ❌ | ❌ | ❌ | **✅ Jitter measurement** |
| Auto-exclude bad nodes | ❌ | ❌ | ❌ | **✅ Config generator skips them** |
| Node classification | ❌ | ❌ | ❌ | **✅ 5-tier classification** |
| Platforms | Clash | Clash/Surge/SR | Clash | **Clash + Shadowrocket + CLI** |

> **These projects are complementary, not competing.** Rule projects manage *domains*, this project manages *nodes*. Use them together — [blackmatrix7](https://github.com/blackmatrix7/ios_rule_script) for rules, Clash AI Proxy for node selection.

## Real-World Pitfalls

This project is born from hours of real debugging. Full details in [`docs/pitfalls.md`](docs/pitfalls.md):

| Pitfall | Impact | How CLI catches it |
|---------|--------|---------------------|
| **HK nodes dead for OpenAI** | Same exit IP as USA, but routing returns `000` | `test` command shows ChatGPT fails on specific nodes |
| **LU (Luxembourg) blocked by Google** | FranTech IP range partially rejected | `latency` shows high jitter + `test` shows Gemini fails |
| **Gemini iOS checks GPS/SIM** | Proxy alone doesn't fix mobile | Documented in pitfalls — disable Location Services |
| **`url-test` picks jittery nodes** | 400ms avg with 1900ms spikes = unusable | `latency` reveals jitter, recommends `fallback` |
| **Fake nodes in subscription** | "Remaining Traffic" node gets selected | `latency` identifies and labels them |
| **Cloudflare Bot Management** | Perplexity/Mistral return 403 via curl | `test` distinguishes CF anti-bot from real blocks |
| **Greedy DOMAIN-KEYWORD rules** | `KEYWORD,google` captures Gemini's auxiliary domains | Documented in pitfalls — solution provided |

## CLI Reference

```bash
# Test service reachability through your proxy
clash-ai test --proxy http://127.0.0.1:7897
clash-ai test --proxy http://127.0.0.1:7897 --services chatgpt,gemini,claude

# Test node latency and stability (TCP + TLS handshake)
clash-ai latency --config config.yaml --samples 5
clash-ai latency --config config.yaml --json results.json

# Generate optimized config (auto-excludes dead nodes)
clash-ai generate --config config.yaml --output optimized.yaml
clash-ai generate --config config.yaml --format shadowrocket --output optimized.conf

# Full pipeline: test + classify + generate
clash-ai full --config config.yaml --proxy http://127.0.0.1:7897
```

## Supported Services

| Category | Services |
|----------|----------|
| **AI** | ChatGPT, Claude, Gemini, Grok, Perplexity, Cohere, Character.ai, Mistral, Poe |
| **Streaming** | Netflix, YouTube, Disney+, Hulu, HBO Max, Prime Video, Crunchyroll, Spotify |
| **Social** | Telegram, Discord, Twitter/X, WhatsApp, Instagram |
| **Dev** | GitHub, Docker Hub, PyPI, npm, Vercel, Netlify, Supabase |

Add your own in [`clash_ai_proxy/services.py`](clash_ai_proxy/services.py) — just add a dict entry.

## Contributing

Contributions welcome! Especially:

- 🌍 **New service definitions** — add services from your region
- 🐛 **Dead-node patterns** — report which airports have which dead nodes for which services
- 🔧 **New proxy clients** — add support for Surge, Quantumult X, sing-box
- 📝 **Pitfall documentation** — found a new gotcha? Add it to `docs/pitfalls.md`
- 🌐 **Translations** — README in Chinese, Japanese, Korean, etc.

## Who is this for?

- ✅ You use **Clash/mihomo/Shadowrocket** with multiple proxy nodes
- ✅ You access **AI services** (ChatGPT, Claude, Gemini) and need them to **just work**
- ✅ You're tired of manually switching nodes when one stops working for a specific service
- ✅ You want your proxy config to be **smart about service-specific routing**

Not for you if: you only use one node, or you don't access geo-restricted services.

## Changelog

### v1.2.0 (2026-10-05)

**Engine-level optimizations (mihomo kernel features):**

| Change | Impact |
|--------|--------|
| `tcp-concurrent: true` | Parallel TCP connection racing — auto-selects fastest path, reduces cold start 30-50% |
| `sniffer` enabled | Restores real domain from TLS SNI/HTTP Host — makes DOMAIN rules work under fake-ip (was relying on GeoIP fallback) |
| `geodata-mode: true` | Uses `.dat` format instead of `.mmdb` — 40% less memory, faster GeoIP lookups |
| GeoSite rules (`GEOSITE,google` etc.) | Covers 200+ domains per category vs our manual 20 — catches auxiliary domains we missed |
| `nameserver-policy` | AI domains (ChatGPT/Claude/Gemini) resolve via Google DoH directly — 200ms+ faster than going through Chinese DoH |
| `max-failed-times: 3` | Auto-switches to next node after 3 consecutive failures — no more waiting for interval to expire |
| `keep-alive-interval: 30` | Reduced from default 15s — saves battery on mobile, reduces unnecessary traffic |
| `global-client-fingerprint: chrome` | Unified TLS fingerprint at global level — cleaner configs, consistent browser impersonation |

### v1.1.0 (2026-10-05)

**Architecture upgrades (battle-tested with real airports):**

| Change | Why |
|--------|-----|
| `lazy: false` on all fallback groups | Keeps connections warm — eliminates anytls cold-start latency (first request 1900ms → 400ms) |
| `fake-ip-filter` includes AI domains | Prevents DNS leak detection for ChatGPT/Gemini/Claude — they need real DNS resolution |
| `rule-providers` from blackmatrix7 | Remote rulesets auto-update daily — better coverage than manual domain lists |
| Node priority sorting (`-02` first) | In practice, `-02` entry points have 4ms jitter vs 1110ms on `-01` for same physical server |
| IPv6 disabled by default | Many airports lack IPv6 support — leaving it on causes DNS leaks and routing failures |
| DNS fallback to DoH (`1.1.1.1`) | Reliable DNS resolution even when ISP DNS is tampered with |
| `CF-Strict` group added | Cloudflare Bot Management services (Perplexity/Mistral/Poe) need manual node selection |

**New services added (15 → 30+):**

Mistral, Cohere, Character.ai, Poe, HBO Max, Prime Video, Crunchyroll, Spotify, WhatsApp, npm, PyPI, Vercel, Binance, Coinbase, OpenSea, Cursor, GitHub Copilot, Hugging Face, Replit

**New `KNOWN_DEAD_NODES` database:**

Community-contributed dead-node patterns by airport. Currently documents the `lyhycloud` airport's known issues (HK dead for OpenAI, JP-01 dead on iOS, LU blocked by Google, UK high jitter, Warp-CF WireGuard dead). Add your findings in [`services.py`](clash_ai_proxy/services.py).

**New pitfalls documented:**

- Gemini iOS region detection (IP + GPS + SIM + Apple ID — proxy alone insufficient)
- Shadowrocket greedy `DOMAIN-KEYWORD,google` capturing Gemini auxiliary domains
- `anytls` cold-start latency (first request penalty)
- Fake nodes ("Remaining Traffic") hijacking `url-test`

Full details in [`docs/pitfalls.md`](docs/pitfalls.md).

### v1.0.0

Initial release. CLI tool with `test`, `latency`, `generate`, `full` commands. 11-layer proxy group architecture. Clash + Shadowrocket support.

---

## License

[MIT](LICENSE)

## Star History

If this project helped you diagnose proxy issues, give it a ⭐ — it helps others discover it.
